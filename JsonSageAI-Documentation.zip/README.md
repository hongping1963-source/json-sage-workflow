# JsonSageAI 文档中心

## 1. 核心文档
- [技术规格说明书](./TECHNICAL_SPEC.md)
- [测试报告](./TEST_REPORT.md)
- [竞争优势分析](./COMPETITIVE_ADVANTAGE.md)

## 2. 用户指南
- [快速开始](./guides/QUICK_START.md)
- [多产品支持指南](./guides/MULTI_PRODUCT_GUIDE.md)
- [高级特性指南](./guides/ADVANCED_FEATURES.md)
- [常见问题](./guides/FAQ.md)

## 3. API 文档
- [API 参考](./api/API_REFERENCE.md)
- [类型定义](./api/TYPE_DEFINITIONS.md)
- [错误代码](./api/ERROR_CODES.md)

## 4. 部署文档
- [部署指南](./deployment/DEPLOYMENT.md)
- [环境配置](./deployment/ENVIRONMENT.md)
- [监控和维护](./deployment/MONITORING.md)

## 5. 示例代码
- [基础产品目录](../examples/product-catalog.ts)
- [多产品支持](../examples/multi-products.ts)
- [增强版多产品支持](../examples/enhanced-multi-products.ts)

## 6. 贡献指南
- 代码规范
- 提交指南
- 测试规范

## 7. 更新日志
- 版本历史
- 重大变更
- 废弃特性

## 8. 社区资源
- 常见问题
- 最佳实践
- 社区贡献

## 使用说明

1. **新手入门**：
   - 阅读[快速开始](./guides/QUICK_START.md)指南
   - 查看基础示例代码
   - 了解核心概念

2. **进阶学习**：
   - 深入了解[技术规格](./TECHNICAL_SPEC.md)
   - 学习[高级特性](./guides/ADVANCED_FEATURES.md)
   - 研究[多产品支持](./guides/MULTI_PRODUCT_GUIDE.md)

3. **技术参考**：
   - 查阅 [API 文档](./api/API_REFERENCE.md)
   - 了解[部署要求](./deployment/DEPLOYMENT.md)
   - 掌握[监控方法](./deployment/MONITORING.md)

4. **深入研究**：
   - 阅读[竞争优势分析](./COMPETITIVE_ADVANTAGE.md)
   - 研究测试报告和性能数据
   - 了解技术发展路线

## 文档更新

本文档持续更新中。如有问题或建议，请通过以下方式反馈：
1. 提交 Issue
2. 发送邮件
3. 参与讨论

最后更新时间：2025-01-20
